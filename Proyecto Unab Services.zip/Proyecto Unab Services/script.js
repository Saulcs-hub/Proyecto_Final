document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar elementos
    const inputs = document.querySelectorAll('input');
    const loginBtn = document.getElementById('loginBtn');
    
    // Añadir efecto a los inputs
    inputs.forEach(input => {
        // Añadir clase 'active' cuando el input tiene contenido
        input.addEventListener('input', function() {
            if (this.value.length > 0) {
                this.parentElement.classList.add('active');
            } else {
                this.parentElement.classList.remove('active');
            }
        });
        
        // Añadir efecto de onda al hacer click
        input.addEventListener('focus', function() {
            this.style.transition = 'all 0.3s ease';
            this.style.transform = 'scale(1.01)';
        });
        
        input.addEventListener('blur', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Efecto al botón de login
    loginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Validación simple
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (!username || !password) {
            shakeElement(this);
            return;
        }
        
        // Animación de éxito
        this.innerHTML = '<span style="display: inline-block; animation: spin 1s infinite linear;">&#10227;</span> Verificando...';
        this.style.pointerEvents = 'none';
        
        // Simulación de proceso de login (para demostración)
        setTimeout(() => {
            this.innerHTML = '¡Acceso Exitoso!';
            this.style.backgroundColor = '#2e7d32';
            
            // Redirigir o mostrar el dashboard aquí
            setTimeout(() => {
                alert('¡Login simulado exitoso!');
                // window.location.href = 'dashboard.html'; // Descomenta para redirigir
            }, 1000);
        }, 1500);
    });
    
    // Función para efecto de shake
    function shakeElement(element) {
        element.classList.add('animate__animated', 'animate__shakeX');
        setTimeout(() => {
            element.classList.remove('animate__animated', 'animate__shakeX');
        }, 1000);
    }
    
    // Efecto parallax suave en la imagen
    const leftImage = document.querySelector('.left-section img');
    window.addEventListener('mousemove', function(e) {
        const moveX = (e.clientX - window.innerWidth / 2) * 0.01;
        const moveY = (e.clientY - window.innerHeight / 2) * 0.01;
        leftImage.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.05)`;
    });
    
    // Animación para el enlace de contraseña olvidada
    const forgotLink = document.querySelector('.forgot-password');
    forgotLink.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.05)';
    });
    
    forgotLink.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
    
    // Validación en tiempo real para los campos
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    usernameInput.addEventListener('input', function() {
        validateField(this);
    });
    
    passwordInput.addEventListener('input', function() {
        validateField(this);
    });
    
    function validateField(field) {
        if (field.value.length > 0) {
            field.style.borderColor = '#4CAF50';
        } else {
            field.style.borderColor = '#ccc';
        }
    }
    
    // Keypress para efecto visual
    document.addEventListener('keypress', function() {
        const randomColor = getRandomColor(0.1);
        document.body.style.boxShadow = `0 0 100px ${randomColor} inset`;
        setTimeout(() => {
            document.body.style.boxShadow = 'none';
        }, 300);
    });
    
    function getRandomColor(opacity) {
        return `rgba(76, 175, 80, ${opacity})`;
    }
});

// Animación para keyframes en CSS (compatible con IE)
if (!window.AnimationEvent) {
    document.documentElement.className += ' no-animation';
}

// Añadir animación al cargar la página
window.addEventListener('load', function() {
    document.querySelector('.left-section').classList.add('animate__fadeIn');
    document.querySelector('.right-section').classList.add('animate__fadeIn');
});